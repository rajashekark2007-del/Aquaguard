/*
 * AquaGuard - ESP32 Smart Water Telemetry Node
 * Hardware: ESP32 + YF-S201 Flow Sensor + HC-SR04 Ultrasonic Sensor + Relay
 * Hackathon: YUKTHI 2026 | Team: Idea Igniters
 */

#include <WiFi.h>

#define FLOW_SENSOR_PIN   4   // YF-S201 pulse pin
#define TRIG_PIN          5   // HC-SR04 Trig
#define ECHO_PIN          18  // HC-SR04 Echo
#define RELAY_PUMP_PIN    23  // Pump cutoff relay

const float CALIBRATION_FACTOR = 7.5; // pulses/sec per L/min
const float TANK_MAX_DEPTH_CM  = 200.0;

volatile unsigned int pulseCount = 0;
float currentFlowRateL_min = 0.0;
unsigned long oldTime = 0;

void IRAM_ATTR pulseCounter() {
  pulseCount++;
}

float measureTankLevelPercentage() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);

  long duration = pulseIn(ECHO_PIN, HIGH, 30000);
  if (duration == 0) return -1.0;

  float distanceCm = (duration * 0.0343) / 2.0;
  float waterDepth = TANK_MAX_DEPTH_CM - distanceCm;
  if (waterDepth < 0) waterDepth = 0;

  float percentage = (waterDepth / TANK_MAX_DEPTH_CM) * 100.0;
  return constrain(percentage, 0.0, 100.0);
}

void setup() {
  Serial.begin(115200);
  pinMode(FLOW_SENSOR_PIN, INPUT_PULLUP);
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  pinMode(RELAY_PUMP_PIN, OUTPUT);
  digitalWrite(RELAY_PUMP_PIN, HIGH);

  attachInterrupt(digitalPinToInterrupt(FLOW_SENSOR_PIN), pulseCounter, FALLING);
  oldTime = millis();
}

void loop() {
  if ((millis() - oldTime) > 1000) {
    detachInterrupt(digitalPinToInterrupt(FLOW_SENSOR_PIN));
    currentFlowRateL_min = ((1000.0 / (millis() - oldTime)) * pulseCount) / CALIBRATION_FACTOR;
    oldTime = millis();
    pulseCount = 0;
    attachInterrupt(digitalPinToInterrupt(FLOW_SENSOR_PIN), pulseCounter, FALLING);

    float tankLevel = measureTankLevelPercentage();
    bool overflowRisk = (tankLevel >= 95.0 && currentFlowRateL_min > 5.0);

    if (overflowRisk) {
      digitalWrite(RELAY_PUMP_PIN, LOW); // Cut off pump
    } else {
      digitalWrite(RELAY_PUMP_PIN, HIGH);
    }

    Serial.printf("{\"zone\":\"Zone_C\",\"flow_lpm\":%.2f,\"tank_level_pct\":%.1f,\"overflow_risk\":%s}\n",
                  currentFlowRateL_min, tankLevel, overflowRisk ? "true" : "false");
  }
}
