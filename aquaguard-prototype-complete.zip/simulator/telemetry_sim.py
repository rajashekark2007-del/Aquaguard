"""
AquaGuard Telemetry & Rule Engine Simulator
Calculates volumetric excess water loss and explainable PriorityScore (0-100).
"""

import time
import json
from datetime import datetime

ZONES = {
    "Zone_A": {"name": "Campus Kitchen", "baseline_max": 6.0, "is_night": False},
    "Zone_B": {"name": "Hostel Bathrooms", "baseline_max": 0.0, "is_night": True},
    "Zone_C": {"name": "Overhead Tank", "baseline_max": 0.0, "is_night": True}
}

def evaluate_zone(zone_id, flow_rate, duration_mins, tank_level=None):
    cfg = ZONES[zone_id]
    baseline = cfg["baseline_max"]
    excess_flow = max(0.0, flow_rate - baseline)
    excess_litres = round(excess_flow * duration_mins, 1)

    score = 0
    reason = "Normal scheduled usage."
    status = "NORMAL"

    if zone_id == "Zone_C" and tank_level is not None and tank_level >= 95.0 and flow_rate > 2.0:
        score = 95
        status = "URGENT INSPECTION"
        reason = f"Tank level at {tank_level}% with active inlet pump ({flow_rate} L/min). Float-valve failure suspected."
    elif zone_id == "Zone_B" and flow_rate > 0.1 and cfg["is_night"]:
        score = min(100, int(30 + (excess_flow * 40) + (duration_mins * 0.3)))
        status = "WARNING" if score < 80 else "URGENT INSPECTION"
        reason = f"Uninterrupted night flow of {flow_rate} L/min detected for {duration_mins} minutes."
    else:
        score = int((flow_rate / (baseline + 1.0)) * 15)

    return {
        "zone_id": zone_id,
        "facility": cfg["name"],
        "timestamp": datetime.now().isoformat(),
        "flow_lpm": flow_rate,
        "excess_loss_litres": excess_litres,
        "priority_score": score,
        "status": status,
        "diagnostic_reason": reason
    }

if __name__ == "__main__":
    print("AquaGuard Rule Engine Telemetry Test:")
    sample = [
        ("Zone_A", 4.0, 30, 80),
        ("Zone_B", 0.5, 60, None),
        ("Zone_C", 15.0, 10, 99.0)
    ]
    for zid, f, d, t in sample:
        print(json.dumps(evaluate_zone(zid, f, d, t), indent=2))
